# Outreach draft 02 — RINWA Berlin (La Red — Vernetzung und Integration e.V.)

**STATUS**: DRAFTED — NOT YET SENT — TARGET SEND: WEEK 4 START

**Contact details last verified**: 2026-05-18 via La Red RINWA project page. Re-verify within the week before sending; RINWA is a fresh 2026 successor to IQ-Netzwerk Berlin and the staffing may shift in early operation.

---

## Contact

| Field | Value |
|---|---|
| Name | Cristina Faraco Blanco |
| Role | RINWA Koordination (project coordinator) |
| Organisation | La Red — Vernetzung und Integration e.V. |
| Direct email | `faraco@la-red.eu` |
| Phone | +49 30 457989 550 |
| RINWA service tracks | WA Service (service/climate/environment), WA MINT+ (IT/tech), WA Cura (care/healthcare) |

## Selection rationale

The IQ-Netzwerk programme structurally morphed into the **Regionale Integrationsnetzwerke Willkommens- und Anerkennungskultur (RINWA)** in 2026; the prior IQ Berlin coordination at VIA-in-Berlin (Petersburger Straße 92) closed at end-2025. The two 2026 successor coordinators are La Red and Arbeit und Leben Berlin-Brandenburg gGmbH. La Red is the named project lead for RINWA Berlin and has Cristina Faraco Blanco as the project coordinator (verified on la-red.eu).

Picked La Red over Arbeit und Leben Berlin-Brandenburg because La Red has explicit RINWA project ownership and a long-standing Anerkennungsberatung service track. Arbeit und Leben remains a credible alternative if La Red declines or doesn't respond.

## Fit reasons for personalisation

1. **Persona panel ↔ RINWA service tracks**: WA Cura covers Aïcha (Tunisian nurse, §16d Anerkennung) and Maria (Romanian Pflegekraft); WA MINT+ covers Yusuf (Turkish engineer, EU Blue Card) and Olga (Ukrainian senior frontend dev, §24); WA Service covers Mahmoud (Syrian Ausbildung in Handwerk, subsidiary protection). The mapping is exact, not approximate.
2. RINWA's stated mission ("erfolgreiche Gewinnung, Beschäftigung und langfristige Integration internationaler Fachkräfte") is the same outcome as our cost-saving doctrine (Decision 7 in `04-research-and-decisions.md`). Our user-facing open-source civic-commons mode is the structural complement to RINWA's employer-side training-and-counselling model.

## Draft message (German)

**Betreff**: Anfrage — Open-Source-Tool für die Anerkennungs- und Bewerbungsbegleitung internationaler Fachkräfte

Sehr geehrte Frau Faraco Blanco,

mein Name ist [Maintainer]. Ich bin Student an der TU Berlin und entwickle **DirectJob Scout** — ein Open-Source-Tool, das internationale Fachkräfte durch den Anerkennungs- und Bewerbungsprozess in Deutschland führt. Mehrsprachig, datenschutzkonform (lokal selbst hostbar, verschlüsselt), Apache-2.0-lizenziert und im Vorgriff auf den EU AI Act bereits dokumentiert.

Das Projekt deckt sich strukturell mit den drei Servicelinien von RINWA auf eine Weise, die mir auffällig genau erscheint:

1. **WA Cura** — unsere Anchor-Personas Aïcha (tunesische Krankenpflegerin, § 16d Anerkennung) und Maria (rumänische Pflegekraft) sind genau die Profile, die WA Cura adressiert. Anerkennungsfreundliche Arbeitgebersuche und Lebensläufe in klinischem Deutsch sind im Tool bereits umgesetzt.
2. **WA MINT+** — Yusuf (türkischer Maschinenbauingenieur, EU Blue Card im Verfahren) und Olga (ukrainische Senior-Frontend-Entwicklerin, § 24) bilden den IT/Technik-Bereich ab.
3. **WA Service** — Mahmoud (syrischer Auszubildender im Handwerk, subsidiärer Schutz) bedient den Service- und Handwerksbereich, einschließlich Ausbildungs-Aggregation und Handwerk-Lebenslaufformat.

Die Vision deckt sich strukturell mit der RINWA-Mission: spezialisiertes Wissen rund um Anerkennung und Arbeitsmarktintegration in die Hände der Betroffenen selbst zu geben — und gleichzeitig die Träger Ihres Netzwerks zu entlasten.

Wir bewerben uns in den nächsten Wochen um eine Förderung beim NLnet NGI Zero Commons Fund (EU-finanziert). Ein Empfehlungsschreiben des Berliner RINWA-Netzwerks würde unsere zivilgesellschaftliche Verankerung gegenüber dem Geldgeber konkret sichtbar machen.

Wäre eine kurze Vorstellung (15–20 Minuten online) für Sie möglich? Alternativ kann ich Ihnen eine schriftliche Vorlage für ein Unterstützungsschreiben zusenden, sodass Sie nur ca. 5 Minuten investieren müssten.

Mit freundlichen Grüßen,
[Maintainer]
[Kontakt-Email]
[Link zum Projekt-README / Demo]

## Placeholders to fill before send

- `[Maintainer]` — your preferred display name
- `[Kontakt-Email]` — your direct reply-to email
- `[Link zum Projekt-README / Demo]` — single link, ideally the demo URL once Week 3 ships it
